int qemu_set_fd_handler2(int fd,

                         IOCanReadHandler *fd_read_poll,

                         IOHandler *fd_read,

                         IOHandler *fd_write,

                         void *opaque)

{

    IOHandlerRecord *ioh;



    assert(fd >= 0);



    if (!fd_read && !fd_write) {

        QLIST_FOREACH(ioh, &io_handlers, next) {

            if (ioh->fd == fd) {

                ioh->deleted = 1;

                break;

            }

        }

    } else {

        QLIST_FOREACH(ioh, &io_handlers, next) {

            if (ioh->fd == fd)

                goto found;

        }

        ioh = g_malloc0(sizeof(IOHandlerRecord));

        QLIST_INSERT_HEAD(&io_handlers, ioh, next);

    found:

        ioh->fd = fd;

        ioh->fd_read_poll = fd_read_poll;

        ioh->fd_read = fd_read;

        ioh->fd_write = fd_write;

        ioh->opaque = opaque;

        ioh->pollfds_idx = -1;

        ioh->deleted = 0;

        qemu_notify_event();

    }

    return 0;

}
