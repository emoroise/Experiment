void qmp_qmp_capabilities(Error **errp)

{

    cur_mon->qmp.in_command_mode = true;

}
