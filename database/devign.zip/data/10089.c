void bdrv_init(void)

{

    module_call_init(MODULE_INIT_BLOCK);

}
