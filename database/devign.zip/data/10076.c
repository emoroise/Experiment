int bdrv_is_sg(BlockDriverState *bs)

{

    return bs->sg;

}
