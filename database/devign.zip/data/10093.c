int bdrv_enable_write_cache(BlockDriverState *bs)

{

    return bs->enable_write_cache;

}
