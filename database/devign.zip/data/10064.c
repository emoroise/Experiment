static int qsort_strcmp(const void *a, const void *b)

{

    return strcmp(a, b);

}
