const char *bdrv_get_node_name(const BlockDriverState *bs)

{

    return bs->node_name;

}
