void bdrv_enable_copy_on_read(BlockDriverState *bs)

{

    bs->copy_on_read++;

}
