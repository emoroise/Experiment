int bdrv_is_read_only(BlockDriverState *bs)

{

    return bs->read_only;

}
