int64_t qmp_guest_fsfreeze_freeze(Error **err)

{

    error_set(err, QERR_UNSUPPORTED);

    return 0;

}
